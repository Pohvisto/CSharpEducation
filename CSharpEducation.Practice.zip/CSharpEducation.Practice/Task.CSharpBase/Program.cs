﻿int Age;
string Name;
string NameCompany;
bool Logical;
float HumanWt;