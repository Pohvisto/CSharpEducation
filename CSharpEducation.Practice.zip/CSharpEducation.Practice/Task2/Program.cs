﻿int Age = 21;
string Name = "Marsel'";
int Temperature = 5;
bool Woman = false;