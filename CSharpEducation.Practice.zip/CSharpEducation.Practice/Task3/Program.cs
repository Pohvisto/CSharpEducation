﻿Console.WriteLine("Как тебя зовут?");
string Name = Console.ReadLine();
Console.WriteLine($"Привет {Name}");