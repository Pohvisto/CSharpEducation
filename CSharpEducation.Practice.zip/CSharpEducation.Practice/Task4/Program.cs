﻿Console.WriteLine("Как вас зовут?");
string First = Console.ReadLine();
Console.WriteLine("Сколько вам лет?");
string Second = Console.ReadLine();
Console.WriteLine("Вас зовут " + First + ", вам "+Second+" лет");