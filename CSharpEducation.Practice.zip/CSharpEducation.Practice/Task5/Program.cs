﻿const float PI= 3.14F;
int Radius = 5;
Console.WriteLine(PI*Math.Pow(Radius, 2));