﻿//a
int a = 3;
int b = 4;
Console.WriteLine(Math.Sqrt(Math.Pow(a, 2) + Math.Pow(b, 2)));
//b
int aa = 3;
int cc = 5;
Console.WriteLine(Math.Sqrt(Math.Pow(cc, 2) - Math.Pow(aa, 2)));
